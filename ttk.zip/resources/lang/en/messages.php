<?php

return [

    'username_validated' => 'Username is valid',
    'username_not_validated' => 'Username is not registered',

    // Phone Verification code
    'user_verified' => 'User successfully verified.',
    'given_code_invalid' => 'Given code is invalid',
    'user_already_verified' => 'User is already verified',
];
