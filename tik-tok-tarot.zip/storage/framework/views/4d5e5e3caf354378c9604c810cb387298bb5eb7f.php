<!DOCTYPE html>
<html lang="en-US">
  <head>
    <meta charset="utf-8" />
    
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <style>
    html, body {
      background-color: #fff;
      color: #636b6f;
      font-family: 'Raleway', sans-serif;
      font-weight: 100;
      height: 100vh;
      margin: 0;
    }

    .full-height {
      height: 100vh;
    }

    .flex-center {
      align-items: center;
      display: flex;
      justify-content: center;
    }

    .position-ref {
      position: relative;
    }

    .content {
      text-align: center;
    }

    .title {
      font-size: 36px;
      padding: 20px;
    }
    </style>
  </head>
  <body>
    <table>
      <tr>
        <td style="text-align: left; width:120px"></td>
        <th style="text-align: left;"><h3><b>Basic Info</b></h3></th>
      </tr>
      <tr>
        <td style="text-align: left;">Name</td>
        <th style="text-align: left;"><?php echo e($fullName); ?></th>
      </tr>
      <tr>
        <td style="text-align: left;">Username</td>
        <th style="text-align: left;"><?php echo e($userName); ?></th>
      </tr>
      <tr>
        <td style="text-align: left;">Email</td>
        <th style="text-align: left;"><?php echo e($email); ?></th>
      </tr>
      <tr>
        <td style="text-align: left;">Phone number</td>
        <th style="text-align: left;"><?php echo e($phoneNumber); ?></th>
      </tr>
      <tr>
        <td style="text-align: left;"></td>
        <th style="text-align: left;"><h3><b>Security Questions</b></h3></th>
      </tr>
      <?php $__currentLoopData = $securityQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $securityQuestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr >
          <td style="text-align: left;">Question #<?php echo e($key + 1); ?></td>
          <th style="text-align: left;"><?php echo e($securityQuestion->_security_question); ?></th>
        </tr>
        <tr >
          <td style="text-align: left;">Answer</td>
          <th style="text-align: left;"><?php echo e($securityQuestion->answer); ?></th>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </table>
  </body>
</html><?php /**PATH C:\laragon\www\tik-tok-tarot\resources\views/emails/test.blade.php ENDPATH**/ ?>