<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/api/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::i0RLFSwCQju2b6IJ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2b1LHztaI1YRBhHc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/settings/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::M2CFGzlCzGggP5TV',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/settings/password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NJsyk3Gp7TlKw1hl',
          ),
          1 => NULL,
          2 => 
          array (
            'PATCH' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/authenticated-security-question' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Je8bUlRfdxU8CFQ6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/authenticated-user-security-question' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kPsgIkmGHqBGVx5u',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/authenticated-user-security-question/save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wqoiOBw1FecBAxCo',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/verification/verify-user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::c0GpsDXCF6NstqZu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mg5Xaxdum3QNjpfq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YmEvQvgGOknbig41',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user/validate-username' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::s56gwAWzBApmuK5A',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user/validate-email' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xlNkH8nXYLxYlT3Z',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/security-question' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KUXeoGltcaJD7wYl',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/security-question/save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ue5gY9ctzDHfo4wB',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/security-question/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::23L9pEu6Gq9vETD4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user-security-question' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9Xo7ZKDjkCldPixV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user-security-question/save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rT6ewwyoMqU7yRA1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user-security-question/delete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TPk8N1NLyEZKw0b7',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/email/send-email' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5binI7NrU68oMCUw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/forgot-password/user-security-questions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::b9Lj4QaXE1yQjedN',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/forgot-password/check-security-question' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QAsRzt0C1rUTxxNC',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/password/email' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zNhdvNK5WHZRUkUh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/password/reset' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mgUW8mS2b058gStV',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/password/custom-reset' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Rv8GCeWaDdW2MZL7',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/email/resend' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::K10WHWUCIMn3PkTM',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/footer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gCk6qm2pPFhC5HET',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/footer/save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::T8y7T1yFsm1VIolf',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/how-to' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xQWK3eGDO4BkGGpu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/how-to/save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dQo2vm36xIkxqkt8',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/faq' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6zdlOxASRMe4u0JF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/faq/save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Y6Jys7YCOzErjaYw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/upload/save' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HrJuYLIXq3orqXzL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/_dusk/(?|log(?|in/([^/]++)(?:/([^/]++))?(*:48)|out(?:/([^/]++))?(*:72))|user(?:/([^/]++))?(*:98))|/api/(?|email/verify/([^/]++)(*:135)|upload/featured\\-uploads/([^/]++)(*:176)|oauth/([^/]++)(?|(*:201)|/callback(*:218)))|/((?:.*))(*:237))/?$}sDu',
    ),
    3 => 
    array (
      48 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::G9msWzHRjqgzPmfQ',
            'guard' => NULL,
          ),
          1 => 
          array (
            0 => 'userId',
            1 => 'guard',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      72 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HMzcRrImebSbvC2G',
            'guard' => NULL,
          ),
          1 => 
          array (
            0 => 'guard',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      98 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OoqqwThU4ndqbp8Z',
            'guard' => NULL,
          ),
          1 => 
          array (
            0 => 'guard',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      135 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'verification.verify',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      176 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gcIJZ9qebnwCuvpH',
          ),
          1 => 
          array (
            0 => 'typeName',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      201 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8rxlt1f7rCMemuKw',
          ),
          1 => 
          array (
            0 => 'driver',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      218 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'oauth.callback',
          ),
          1 => 
          array (
            0 => 'driver',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      237 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2RcTFuSMlNRwrq3E',
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::G9msWzHRjqgzPmfQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_dusk/login/{userId}/{guard?}',
      'action' => 
      array (
        'middleware' => 'web',
        'uses' => 'Laravel\\Dusk\\Http\\Controllers\\UserController@login',
        'controller' => 'Laravel\\Dusk\\Http\\Controllers\\UserController@login',
        'as' => 'generated::G9msWzHRjqgzPmfQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::HMzcRrImebSbvC2G' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_dusk/logout/{guard?}',
      'action' => 
      array (
        'middleware' => 'web',
        'uses' => 'Laravel\\Dusk\\Http\\Controllers\\UserController@logout',
        'controller' => 'Laravel\\Dusk\\Http\\Controllers\\UserController@logout',
        'as' => 'generated::HMzcRrImebSbvC2G',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::OoqqwThU4ndqbp8Z' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_dusk/user/{guard?}',
      'action' => 
      array (
        'middleware' => 'web',
        'uses' => 'Laravel\\Dusk\\Http\\Controllers\\UserController@user',
        'controller' => 'Laravel\\Dusk\\Http\\Controllers\\UserController@user',
        'as' => 'generated::OoqqwThU4ndqbp8Z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::i0RLFSwCQju2b6IJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@logout',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::i0RLFSwCQju2b6IJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::2b1LHztaI1YRBhHc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\UserController@current',
        'controller' => 'App\\Http\\Controllers\\Auth\\UserController@current',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::2b1LHztaI1YRBhHc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::M2CFGzlCzGggP5TV' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/settings/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Settings\\ProfileController@update',
        'controller' => 'App\\Http\\Controllers\\Settings\\ProfileController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::M2CFGzlCzGggP5TV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::NJsyk3Gp7TlKw1hl' => 
    array (
      'methods' => 
      array (
        0 => 'PATCH',
      ),
      'uri' => 'api/settings/password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Settings\\PasswordController@update',
        'controller' => 'App\\Http\\Controllers\\Settings\\PasswordController@update',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::NJsyk3Gp7TlKw1hl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Je8bUlRfdxU8CFQ6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/authenticated-security-question',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\SecurityQuestionController@authenticated',
        'controller' => 'App\\Http\\Controllers\\Auth\\SecurityQuestionController@authenticated',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/authenticated-security-question',
        'where' => 
        array (
        ),
        'as' => 'generated::Je8bUlRfdxU8CFQ6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::kPsgIkmGHqBGVx5u' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/authenticated-user-security-question',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\UserSecurityQuestionController@authenticated',
        'controller' => 'App\\Http\\Controllers\\Auth\\UserSecurityQuestionController@authenticated',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/authenticated-user-security-question',
        'where' => 
        array (
        ),
        'as' => 'generated::kPsgIkmGHqBGVx5u',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::wqoiOBw1FecBAxCo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/authenticated-user-security-question/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\UserSecurityQuestionController@saveAuthenticated',
        'controller' => 'App\\Http\\Controllers\\Auth\\UserSecurityQuestionController@saveAuthenticated',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/authenticated-user-security-question',
        'where' => 
        array (
        ),
        'as' => 'generated::wqoiOBw1FecBAxCo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::c0GpsDXCF6NstqZu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/verification/verify-user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:api',
        ),
        'uses' => 'App\\Http\\Controllers\\PhoneVerificationController@verifyUser',
        'controller' => 'App\\Http\\Controllers\\PhoneVerificationController@verifyUser',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/verification',
        'where' => 
        array (
        ),
        'as' => 'generated::c0GpsDXCF6NstqZu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mg5Xaxdum3QNjpfq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'controller' => 'App\\Http\\Controllers\\Auth\\LoginController@login',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::mg5Xaxdum3QNjpfq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::YmEvQvgGOknbig41' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\RegisterController@register',
        'controller' => 'App\\Http\\Controllers\\Auth\\RegisterController@register',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::YmEvQvgGOknbig41',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::s56gwAWzBApmuK5A' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/user/validate-username',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\UserController@validateUserName',
        'controller' => 'App\\Http\\Controllers\\Auth\\UserController@validateUserName',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/user',
        'where' => 
        array (
        ),
        'as' => 'generated::s56gwAWzBApmuK5A',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xlNkH8nXYLxYlT3Z' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/user/validate-email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\UserController@validateEmail',
        'controller' => 'App\\Http\\Controllers\\Auth\\UserController@validateEmail',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/user',
        'where' => 
        array (
        ),
        'as' => 'generated::xlNkH8nXYLxYlT3Z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::KUXeoGltcaJD7wYl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/security-question',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\SecurityQuestionController@index',
        'controller' => 'App\\Http\\Controllers\\Auth\\SecurityQuestionController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/security-question',
        'where' => 
        array (
        ),
        'as' => 'generated::KUXeoGltcaJD7wYl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Ue5gY9ctzDHfo4wB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/security-question/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\SecurityQuestionController@save',
        'controller' => 'App\\Http\\Controllers\\Auth\\SecurityQuestionController@save',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/security-question',
        'where' => 
        array (
        ),
        'as' => 'generated::Ue5gY9ctzDHfo4wB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::23L9pEu6Gq9vETD4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/security-question/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\SecurityQuestionController@delete',
        'controller' => 'App\\Http\\Controllers\\Auth\\SecurityQuestionController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/security-question',
        'where' => 
        array (
        ),
        'as' => 'generated::23L9pEu6Gq9vETD4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::9Xo7ZKDjkCldPixV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user-security-question',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\UserSecurityQuestionController@index',
        'controller' => 'App\\Http\\Controllers\\Auth\\UserSecurityQuestionController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/user-security-question',
        'where' => 
        array (
        ),
        'as' => 'generated::9Xo7ZKDjkCldPixV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::rT6ewwyoMqU7yRA1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/user-security-question/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\UserSecurityQuestionController@save',
        'controller' => 'App\\Http\\Controllers\\Auth\\UserSecurityQuestionController@save',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/user-security-question',
        'where' => 
        array (
        ),
        'as' => 'generated::rT6ewwyoMqU7yRA1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::TPk8N1NLyEZKw0b7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/user-security-question/delete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\UserSecurityQuestionController@delete',
        'controller' => 'App\\Http\\Controllers\\Auth\\UserSecurityQuestionController@delete',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/user-security-question',
        'where' => 
        array (
        ),
        'as' => 'generated::TPk8N1NLyEZKw0b7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::5binI7NrU68oMCUw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/email/send-email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\SendEmailController@sendEmail',
        'controller' => 'App\\Http\\Controllers\\SendEmailController@sendEmail',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/email',
        'where' => 
        array (
        ),
        'as' => 'generated::5binI7NrU68oMCUw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::b9Lj4QaXE1yQjedN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/forgot-password/user-security-questions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@getUserSecurityQuestion',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@getUserSecurityQuestion',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/forgot-password',
        'where' => 
        array (
        ),
        'as' => 'generated::b9Lj4QaXE1yQjedN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::QAsRzt0C1rUTxxNC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/forgot-password/check-security-question',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@checkUserSecurityQuestion',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@checkUserSecurityQuestion',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/forgot-password',
        'where' => 
        array (
        ),
        'as' => 'generated::QAsRzt0C1rUTxxNC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::zNhdvNK5WHZRUkUh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/password/email',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'controller' => 'App\\Http\\Controllers\\Auth\\ForgotPasswordController@sendResetLinkEmail',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::zNhdvNK5WHZRUkUh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::mgUW8mS2b058gStV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/password/reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@reset',
        'controller' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@reset',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::mgUW8mS2b058gStV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Rv8GCeWaDdW2MZL7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/password/custom-reset',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@customResetPassword',
        'controller' => 'App\\Http\\Controllers\\Auth\\ResetPasswordController@customResetPassword',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::Rv8GCeWaDdW2MZL7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'verification.verify' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/email/verify/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\VerificationController@verify',
        'controller' => 'App\\Http\\Controllers\\Auth\\VerificationController@verify',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'verification.verify',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::K10WHWUCIMn3PkTM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/email/resend',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\VerificationController@resend',
        'controller' => 'App\\Http\\Controllers\\Auth\\VerificationController@resend',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::K10WHWUCIMn3PkTM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::gCk6qm2pPFhC5HET' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/footer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\FooterController@fetchFooter',
        'controller' => 'App\\Http\\Controllers\\FooterController@fetchFooter',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::gCk6qm2pPFhC5HET',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::T8y7T1yFsm1VIolf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/footer/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\FooterController@save',
        'controller' => 'App\\Http\\Controllers\\FooterController@save',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::T8y7T1yFsm1VIolf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::xQWK3eGDO4BkGGpu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/how-to',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\HowToController@fetchHowTo',
        'controller' => 'App\\Http\\Controllers\\HowToController@fetchHowTo',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::xQWK3eGDO4BkGGpu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::dQo2vm36xIkxqkt8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/how-to/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\HowToController@save',
        'controller' => 'App\\Http\\Controllers\\HowToController@save',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::dQo2vm36xIkxqkt8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::6zdlOxASRMe4u0JF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/faq',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\FaqController@fetchFaq',
        'controller' => 'App\\Http\\Controllers\\FaqController@fetchFaq',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::6zdlOxASRMe4u0JF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::Y6Jys7YCOzErjaYw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/faq/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\FaqController@save',
        'controller' => 'App\\Http\\Controllers\\FaqController@save',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::Y6Jys7YCOzErjaYw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::gcIJZ9qebnwCuvpH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/upload/featured-uploads/{typeName}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\UploadController@fetchFeaturedUpload',
        'controller' => 'App\\Http\\Controllers\\UploadController@fetchFeaturedUpload',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/upload',
        'where' => 
        array (
        ),
        'as' => 'generated::gcIJZ9qebnwCuvpH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::HrJuYLIXq3orqXzL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/upload/save',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\UploadController@save',
        'controller' => 'App\\Http\\Controllers\\UploadController@save',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api/upload',
        'where' => 
        array (
        ),
        'as' => 'generated::HrJuYLIXq3orqXzL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::8rxlt1f7rCMemuKw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/oauth/{driver}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\OAuthController@redirectToProvider',
        'controller' => 'App\\Http\\Controllers\\Auth\\OAuthController@redirectToProvider',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::8rxlt1f7rCMemuKw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'oauth.callback' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/oauth/{driver}/callback',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'guest:api',
        ),
        'uses' => 'App\\Http\\Controllers\\Auth\\OAuthController@handleProviderCallback',
        'controller' => 'App\\Http\\Controllers\\Auth\\OAuthController@handleProviderCallback',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'oauth.callback',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
    'generated::2RcTFuSMlNRwrq3E' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{path}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'spa',
        ),
        'uses' => 'App\\Http\\Controllers\\SpaController@__invoke',
        'controller' => 'App\\Http\\Controllers\\SpaController',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => NULL,
        'where' => 
        array (
        ),
        'as' => 'generated::2RcTFuSMlNRwrq3E',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '(.*)',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
    ),
  ),
)
);
